import { ShowDataPosts } from "../../controllers/showDataHome";
export function homeView(){
    
    const showDataView = new ShowDataPosts()

    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = showDataView.showData() 
    
}