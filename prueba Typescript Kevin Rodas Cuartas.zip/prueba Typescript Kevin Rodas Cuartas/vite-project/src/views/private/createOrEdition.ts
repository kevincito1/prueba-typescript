export function updateView(){
    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = `
    <h1>Hola soy el create or edition</h1>
    `
}