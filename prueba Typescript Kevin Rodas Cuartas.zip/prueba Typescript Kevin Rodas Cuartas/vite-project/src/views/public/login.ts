import { VerificatorUser } from "../../controllers/verificatorUser";
export function loginView(){
    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = `
    <form id="formUser">
      <input type="text" id="userEmail">
      <input type="password" id="userPassword">
      <button type="submit" id="action">Entrar</button>
    </form>    
    `
    const $form = document.getElementById("formUser") as HTMLFormElement;
    $form.addEventListener("submit",(e)=>{
        e.preventDefault();

        const $emailUser  = document.getElementById("userEmail") as HTMLInputElement;        
        const $passwordUser = document.getElementById("userPassword") as HTMLInputElement;
        

        if (!$emailUser || !$passwordUser) {
            alert("Todos los campos son requeridos")
            return
          }
       
    const verificatorUserLogged = new VerificatorUser($emailUser.value,$passwordUser.value)
    console.log(verificatorUserLogged)
    return verificatorUserLogged
        
    })


}