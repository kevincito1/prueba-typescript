import { RegisterUser } from "../../controllers/registerUser";

export function registerView(){
    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = `
    <form id="formUser">
      <input type="text" id="userEmail">
      <input type="password" id="userPassword">
      <button type="submit" id="action">registrarse</button>
    </form>    
    `
    const $form = document.getElementById("formUser") as HTMLFormElement;
    $form.addEventListener("submit",(e)=>{
        e.preventDefault();

        const $emailUser  = document.getElementById("userEmail") as HTMLInputElement;        
        const $passwordUser = document.getElementById("userPassword") as HTMLInputElement;
        

        if (!$emailUser || !$passwordUser) {
            alert("Todos los campos son requeridos")
            return
          }
       
    const UserRegisted = new RegisterUser($emailUser.value,$passwordUser.value)
    console.log(UserRegisted)
    return UserRegisted
        
    })
}