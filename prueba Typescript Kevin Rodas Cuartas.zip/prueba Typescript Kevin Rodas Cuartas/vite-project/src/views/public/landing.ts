import { navigateTo } from "../../router";
export function landingView(){
    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = `
    <h1>Bienvenido al Blog</h1>
    <p>Aqui podras ver tus post, agregar, modificar o eliminar tus entradas</p>
    <h2>Primero vamos a verificar tu identidad</h2>
    <button id="login">Ir a Login</button>
    <h2>Si aun no te has registrado, vamos a registrarnos</h2>
    <button id="register">Ir a Registro</button>
    `
    const $loginButton = document.getElementById("login") as HTMLElement;
    const $registerButton = document.getElementById("register") as HTMLElement;

    $loginButton.addEventListener("click",(e)=>{
        e.preventDefault();
        navigateTo("/login");
    })

    $registerButton.addEventListener("click",(e)=>{
        e.preventDefault();
        navigateTo("/register");
    })
}