import { navigateTo } from "../../router";

export function notFoundView(){
    const $app = document.getElementById("app") as HTMLElement;
    $app.innerHTML = `
    <h1 class="title_not_found">Error 404</h1>
    <p class="paragraph_not_found">Pagin no encontrada</p>
    <button id="action" class="not_found_button">Regresar al landing</button>
    `
    const $action = document.getElementById("action") as HTMLElement;
    $action.addEventListener("click", (e) => {
        e.preventDefault();        
        navigateTo("/landing")});

}