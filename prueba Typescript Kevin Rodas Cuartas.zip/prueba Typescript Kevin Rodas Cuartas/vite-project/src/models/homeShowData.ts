export interface DataPosts{
    info:{
        title:string,
        body:string,
        creationDate:string,
        estimatedPublicationDate:string,
        approvalPercentage:Number,
        platform:string,
        postUrl:string
    }[]
    
}

