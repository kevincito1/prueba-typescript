import { routes } from "./helpers/routes";

export function router(){
    const path: string = window.location.pathname;
    const publicRoutes = routes.public.find(route=>
    route.path === path);

    const privateRoutes = routes.private.find(route=>
    route.path === path);

    if(!publicRoutes && !privateRoutes){
        navigateTo("/not-found")
        return;
    }

    if(path == "/"){
        navigateTo("/landing")
        return;
    }    

    if(privateRoutes){
        privateRoutes.component()
        return
    }    

    if(publicRoutes){
        publicRoutes.component()
        return
    }



}

export function navigateTo(path:string):void{
    window.history.pushState({},"",window.location.origin + path);
    router();
}