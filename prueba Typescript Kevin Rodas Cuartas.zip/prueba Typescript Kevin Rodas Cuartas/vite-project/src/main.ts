import { router } from "./router";

const $app = document.getElementById("app");
if(!$app) {
  throw new Error("No app element found");
}
router();