import { registerView } from "../views/public/register";
import { loginView } from "../views/public/login";
import { notFoundView } from "../views/public/notFound";
import { homeView } from "../views/private/home";
import { updateView } from "../views/private/createOrEdition";
import { landingView } from "../views/public/landing";

export const routes = {
    public:[
        {path: "/register", component: registerView},
        {path: "/login", component: loginView},
        {path: "/not-found", component: notFoundView},
        {path: "/landing", component: landingView}
    ],
    private:[
        {path: "/home", component: homeView},
        {path: "/update", component:updateView}
    ]
}