export class RegisterUser{
    email: string;
    password: string;

    constructor(email:string, password:string){
        this.email = email;
        this.password = password;
    }

    async consumeApi(email:string, password:string){
        const urlCreateApi: string = "https://api-posts.codificando.xyz/users/register"
        const userCreated: Response = await fetch(urlCreateApi,
            {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            }
        );

        if(!userCreated.ok) {
            alert("Error al crear usuario");
            return;
        }

        alert('Usuario Creado Exitosamente');        

    }
    }