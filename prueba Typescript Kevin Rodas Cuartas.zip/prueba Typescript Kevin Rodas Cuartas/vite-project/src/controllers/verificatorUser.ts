import { navigateTo } from "../router";

export class VerificatorUser{
    email: string;
    password: string;

    constructor(email:string, password:string){
        this.email = email;
        this.password = password;
    }

    async consumeApi(email:string, password:string){
        const urlLoginApi: string = "https://api-posts.codificando.xyz/auth/login"
        const userLogged: Response = await fetch(urlLoginApi,
            {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            }
        );

        if(userLogged.ok) {
            const token = sessionStorage.setItem("key", "authorized")
            if(token){
                alert("Bienvenido, acceso autorizado")
                navigateTo("/home")
            }
            return;
        }        

        alert('Inicio de sesion denegado');       

    }
    }
