import { DataPosts } from "../models/homeShowData";

export class ShowDataPosts{

    showData(){
    const urlPostsData:string ="https://api-posts.codificando.xyz/posts"
    const eCards = document.getElementById("app") as HTMLElement    
        
    fetch(urlPostsData)
    .then(response => response.json())
    .then((data:DataPosts) => {
        data.info.forEach((post)=>{
            const $container = document.createElement("div") as HTMLElement
            const $title = document.createElement("title") as HTMLTitleElement;
            $title.innerText = post.title;
            const $body = document.createElement("p") as HTMLParagraphElement;
            $body.innerText = post.body;
            const $creationDate = document.createElement("p") as HTMLParagraphElement;
            $creationDate.innerText = post.creationDate;
            const $approvalPercentage = document.createElement("div") as HTMLDivElement;
            $approvalPercentage.innerText = post.approvalPercentage.toString();
            const $platform = document.createElement("p") as HTMLParagraphElement;
            $platform.innerText = post.platform;
            const $postUrl = document.createElement("p") as HTMLParagraphElement;
            $postUrl.innerText = post.postUrl; 

            $container.appendChild($title);
            $container.appendChild($body);
            $container.appendChild($creationDate);
            $container.appendChild($approvalPercentage);
            $container.appendChild($platform);
            $container.appendChild($postUrl);  
            eCards.appendChild($container);

        })
   }
   )}
}